import math
import json

# 1. Chargement du modele
with open("modele_reseau.json", "r", encoding="utf-8") as fichier:
    modele = json.load(fichier)

poids = modele["poids"]
biais = modele["biais"]
echelles = modele["echelles"]
nombre_entrees = 5
nombre_neurones = 4
print("Modele neuronal charge avec succes !")

# 2. Fonctions mathematiques
def sigmoide(x):
    return 1 / (1 + math.exp(-x))

def softmax(scores):
    maximum = max(scores)
    valeurs = [math.exp(score - maximum) for score in scores]
    total = sum(valeurs)
    return [valeur / total for valeur in valeurs]

# 3. Propagation avant
def propagation(entrees):
    scores = []
    for n in range(nombre_neurones):
        somme = biais[n]
        for i in range(nombre_entrees):
            somme += entrees[i] * poids[n][i]
        scores.append(somme)
    probabilites_regime = softmax(scores[:3])
    score_habitat = sigmoide(scores[3])
    return probabilites_regime, score_habitat

# 4. Saisie des caracteristiques
print("\nCARACTERISTIQUES DU NOUVEL ANIMAL")
print("----------------------------------")
nom = input("Nom de l'animal : ")
taille = float(input("Taille en metres : "))
poids_animal = float(input("Poids en kilogrammes : "))
vitesse = float(input("Vitesse en km/h : "))

print("\nType d'appui :")
print("0 : Plantigrade")
print("1 : Digitigrade")
print("2 : Unguligrade")
type_appui = int(input("Votre choix : "))

print("\nTeinte dominante du corps :")
print("0 : Claire")
print("1 : Intermediaire")
print("2 : Foncee")
teinte_corps = int(input("Votre choix : "))

# 5. Verification des saisies
if taille <= 0 or poids_animal <= 0 or vitesse < 0:
    raise ValueError("Les valeurs physiques sont incorrectes.")
if type_appui not in [0, 1, 2]:
    raise ValueError("Le type d'appui doit etre 0, 1 ou 2.")
if teinte_corps not in [0, 1, 2]:
    raise ValueError("La teinte doit etre 0, 1 ou 2.")

# 6. Normalisation
entrees = [
    taille / echelles[0],
    poids_animal / echelles[1],
    vitesse / echelles[2],
    type_appui / echelles[3],
    teinte_corps / echelles[4]
]

# 7. Predictions
probabilites, score_habitat = propagation(entrees)
noms_regimes = ["Carnivore", "Herbivore", "Omnivore"]
noms_habitats = ["Foret", "Savane"]
indice_regime = probabilites.index(max(probabilites))
regime_predit = noms_regimes[indice_regime]

if score_habitat >= 0.5:
    habitat_predit = noms_habitats[1]
else:
    habitat_predit = noms_habitats[0]

# 8. Affichage des resultats
print("\nRESULTATS DES PREDICTIONS")
print("--------------------------")
print("Animal :", nom)
print("\nProbabilites du regime alimentaire :")
for i in range(3):
    print(noms_regimes[i], ":", round(probabilites[i] * 100, 2), "%")
print("\nRegime alimentaire predit :", regime_predit)
print("Score habitat savane :", round(score_habitat, 3))
print("Habitat predit :", habitat_predit)
