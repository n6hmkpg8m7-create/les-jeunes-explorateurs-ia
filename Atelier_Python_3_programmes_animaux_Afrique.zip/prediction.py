# PHASE 1 - PREPARATION DU PROGRAMME 
# Importation, chargement du modèle et définition des fonctions

# Étape 1 : importation des bibliothèques
import math
import json

# Étape 2 : initialisation des données
# Charge les paramètres du modèle entraîné.

# Ouvre le fichier modele_reseau.json en lecture.
with open("modele_reseau.json", "r", encoding="utf-8") as fichier:
    modele = json.load(fichier)

# Étape 3 : récupération des paramètres
# Récupère les poids, les biais et les échelles du modèle.
poids = modele["poids"]
biais = modele["biais"]
echelles = modele["echelles"]

nombre_entrees = 5
nombre_neurones = 4
print("Modele neuronal charge avec succes !")

# Étape 4 : définition des fonctions
# Les fonctions mathématiques sont identiques à celles
# du programme apprentissage.py.

# Fonctions mathématiques
def sigmoide(x):
    return 1 / (1 + math.exp(-x))

def softmax(scores):
    maximum = max(scores)
    valeurs = [math.exp(score - maximum) for score in scores]
    total = sum(valeurs)
    return [valeur / total for valeur in valeurs]

# Propagation avant
def propagation(entrees):
    scores = []
    for n in range(nombre_neurones):
        somme = biais[n]
        for i in range(nombre_entrees):
            somme += entrees[i] * poids[n][i]
        scores.append(somme)
    probabilites_regime = softmax(scores[:3])
    score_habitat = sigmoide(scores[3])
    return probabilites_regime, score_habitat

# PHASE 2 - EXECUTION DU PROGRAMME DE PREDICTION

# Étape 5 : Prédiction utilisant le neurone 

# Demande le nom et les caractéristiques du nouvel animal.
# Les choix du type d'appui et de la teinte sont codés de 0 à 2.

print("\nCARACTERISTIQUES DU NOUVEL ANIMAL")
print("----------------------------------")
nom = input("Nom de l'animal : ")
taille = float(input("Taille en metres : "))
poids_animal = float(input("Poids en kilogrammes : "))
vitesse = float(input("Vitesse en km/h : "))

print("\nType d'appui :")
print("0 : Plantigrade")
print("1 : Digitigrade")
print("2 : Unguligrade")
type_appui = int(input("Votre choix : "))

print("\nTeinte dominante du corps :")
print("0 : Claire")
print("1 : Intermediaire")
print("2 : Foncee")
teinte_corps = int(input("Votre choix : "))

# Vérification des valeurs saisies.
if taille <= 0 or poids_animal <= 0 or vitesse < 0:
    raise ValueError("Les valeurs physiques sont incorrectes.")
if type_appui not in [0, 1, 2]:
    raise ValueError("Le type d'appui doit etre 0, 1 ou 2.")
if teinte_corps not in [0, 1, 2]:
    raise ValueError("La teinte doit etre 0, 1 ou 2.")

# Normalisation
# Divise chaque caractéristique par son échelle.
# Prépare les données pour le réseau entraîné.
entrees = [
    taille / echelles[0],
    poids_animal / echelles[1],
    vitesse / echelles[2],
    type_appui / echelles[3],
    teinte_corps / echelles[4]
]

# Calcul des prédictions
# Calcule les probabilités des régimes alimentaires
# et sélectionne le régime le plus probable.

probabilites, score_habitat = propagation(entrees)
noms_regimes = ["Carnivore", "Herbivore", "Omnivore"]
noms_habitats = ["Foret", "Savane"]
indice_regime = probabilites.index(max(probabilites))
regime_predit = noms_regimes[indice_regime]

# Le seuil de 0,5 permet de choisir l'habitat.
# - 0,5 ou plus : savane
# - moins de 0,5 : forêt
if score_habitat >= 0.5:
    habitat_predit = noms_habitats[1]
else:
    habitat_predit = noms_habitats[0]

# PHASE 3 - RESTITUTION DES RESULTATS

# # Étape 6 : Affiche les probabilités et les prédictions du réseau.

print("\nRESULTATS DES PREDICTIONS")
print("--------------------------")
print("Animal :", nom)
print("\nProbabilites du regime alimentaire :")
for i in range(3):
    print(noms_regimes[i], ":", round(probabilites[i] * 100, 2), "%")
print("\nRegime alimentaire predit :", regime_predit)
print("Score habitat savane :", round(score_habitat, 3))
print("Habitat predit :", habitat_predit)