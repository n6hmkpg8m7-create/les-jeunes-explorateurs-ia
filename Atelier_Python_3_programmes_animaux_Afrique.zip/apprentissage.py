import csv
import math
import random
import json

# 1. Chargement des donnees
animaux = []
with open("animaux.csv", "r", encoding="utf-8") as fichier:
    lecteur = csv.DictReader(fichier)
    for ligne in lecteur:
        entrees = [
            float(ligne["taille"]), float(ligne["poids"]),
            float(ligne["vitesse"]), float(ligne["type_appui"]),
            float(ligne["teinte_corps"])
        ]
        animaux.append({
            "nom": ligne["nom"],
            "entrees": entrees,
            "regime": int(ligne["regime"]),
            "habitat": int(ligne["habitat"])
        })

if not animaux:
    raise ValueError("Aucun animal trouve dans animaux.csv")
print("Nombre d'animaux charges :", len(animaux))

# 2. Normalisation
echelles = [5, 1000, 100, 2, 2]
for animal in animaux:
    animal["entrees"] = [
        valeur / echelle
        for valeur, echelle in zip(animal["entrees"], echelles)
    ]

# 3. Fonctions mathematiques
def sigmoide(x):
    return 1 / (1 + math.exp(-x))

def softmax(scores):
    maximum = max(scores)
    valeurs = [math.exp(score - maximum) for score in scores]
    total = sum(valeurs)
    return [valeur / total for valeur in valeurs]

# 4. Initialisation du reseau
random.seed(42)
nombre_entrees = 5
nombre_neurones = 4
poids = [
    [random.uniform(-0.1, 0.1) for _ in range(nombre_entrees)]
    for _ in range(nombre_neurones)
]
biais = [0.0 for _ in range(nombre_neurones)]

# 5. Propagation avant
def propagation(entrees):
    scores = []
    for n in range(nombre_neurones):
        somme = biais[n]
        for i in range(nombre_entrees):
            somme += entrees[i] * poids[n][i]
        scores.append(somme)
    probabilites_regime = softmax(scores[:3])
    score_habitat = sigmoide(scores[3])
    return probabilites_regime, score_habitat

# 6. Apprentissage
taux_apprentissage = 0.5
nombre_epoques = 5000
nombre_animaux = len(animaux)

for epoque in range(nombre_epoques):
    gradients_poids = [[0.0] * nombre_entrees for _ in range(nombre_neurones)]
    gradients_biais = [0.0] * nombre_neurones

    for animal in animaux:
        entrees = animal["entrees"]
        regime_attendu = animal["regime"]
        habitat_attendu = animal["habitat"]
        probabilites, score_habitat = propagation(entrees)

        for n in range(3):
            erreur = probabilites[n] - (1 if regime_attendu == n else 0)
            gradients_biais[n] += erreur
            for i in range(nombre_entrees):
                gradients_poids[n][i] += erreur * entrees[i]

        erreur_habitat = score_habitat - habitat_attendu
        gradients_biais[3] += erreur_habitat
        for i in range(nombre_entrees):
            gradients_poids[3][i] += erreur_habitat * entrees[i]

    for n in range(nombre_neurones):
        biais[n] -= taux_apprentissage * gradients_biais[n] / nombre_animaux
        for i in range(nombre_entrees):
            poids[n][i] -= taux_apprentissage * gradients_poids[n][i] / nombre_animaux

    if (epoque + 1) % 1000 == 0:
        print("Epoque :", epoque + 1)

# 7. Sauvegarde du modele
modele = {"poids": poids, "biais": biais, "echelles": echelles}
with open("modele_reseau.json", "w", encoding="utf-8") as fichier:
    json.dump(modele, fichier, indent=4, ensure_ascii=False)

print("\nEntrainement termine !")
print("Modele enregistre dans modele_reseau.json")
