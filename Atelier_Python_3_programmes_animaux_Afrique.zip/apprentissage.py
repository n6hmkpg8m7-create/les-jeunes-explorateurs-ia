# PHASE 1 - PREPARATION DU PROGRAMME
# Importation, fichiers, données, paramètres et fonctions

# Étape 1 : importation des bibliothèques
import csv
import math
import random
import json

# Étape 2 : initialisation des données
# Lit les données du fichier animaux.csv.
animaux = []

# Ouvre le fichier CSV en lecture (r).
# UTF-8 permet de lire les caractères accentués.
with open("animaux.csv", "r", encoding="utf-8") as fichier:
    # Lit les colonnes à partir de leurs noms.
    lecteur = csv.DictReader(fichier)

    # Parcourt les lignes du fichier.
    for ligne in lecteur:
        entrees = [
            float(ligne["taille"]), float(ligne["poids"]),
            float(ligne["vitesse"]), float(ligne["type_appui"]),
            float(ligne["teinte_corps"])
        ]
        # Ajoute chaque animal à la liste.
        animaux.append({
            "nom": ligne["nom"],
            "entrees": entrees,
            "regime": int(ligne["regime"]),
            "habitat": int(ligne["habitat"])
        })

if not animaux:
    # Signale une erreur si aucun animal n'est chargé.
    raise ValueError("Aucun animal trouve dans animaux.csv")
print("Nombre d'animaux charges :", len(animaux))

# Étape 3 : initialisation des paramètres
# Les poids sont initialisés avant l'apprentissage.
# Ils seront ajustés pendant l'entraînement.
random.seed(42)
nombre_entrees = 5
nombre_neurones = 4
poids = [
    [random.uniform(-0.1, 0.1) for _ in range(nombre_entrees)]
    for _ in range(nombre_neurones)
]
biais = [0.0 for _ in range(nombre_neurones)]

# Étape 4 : définition des fonctions

# Normalisation des caractéristiques
echelles = [5, 1000, 100, 2, 2]
for animal in animaux:
    animal["entrees"] = [
        valeur / echelle
        for valeur, echelle in zip(animal["entrees"], echelles)
    ]

# Fonctions mathématiques
def sigmoide(x):
    return 1 / (1 + math.exp(-x))

def softmax(scores):
    maximum = max(scores)
    valeurs = [math.exp(score - maximum) for score in scores]
    total = sum(valeurs)
    return [valeur / total for valeur in valeurs]

# Propagation avant
# Transmet les cinq entrées aux quatre neurones.
def propagation(entrees):
    # Prépare la liste des résultats.
    scores = []

    # Parcourt les quatre neurones.
    for n in range(nombre_neurones):
        somme = biais[n]

        # Parcourt les cinq caractéristiques.
        for i in range(nombre_entrees):
            # Multiplie chaque entrée par son poids.
            somme += entrees[i] * poids[n][i]

        # Mémorise le résultat du neurone.
        scores.append(somme)

    # Calcule les probabilités des trois régimes.
    probabilites_regime = softmax(scores[:3])

    # Calcule le score d'habitat entre 0 et 1.
    score_habitat = sigmoide(scores[3])

    # Renvoie les deux résultats.
    return probabilites_regime, score_habitat

# PHASE 2 - ENTRAINEMENT DU RESEAU
# Calcul des erreurs et ajustement des poids et des biais.

# Étape 5 : apprentissage

# Définit les paramètres de l'entraînement.
taux_apprentissage = 0.5
nombre_epoques = 5000
nombre_animaux = len(animaux)

# Répète l'apprentissage pendant 5 000 époques.
for epoque in range(nombre_epoques):

    # Remet les gradients à zéro.
    gradients_poids = [[0.0] * nombre_entrees for _ in range(nombre_neurones)]
    gradients_biais = [0.0] * nombre_neurones

    # Parcourt tous les animaux et récupère leurs données.
    for animal in animaux:
        entrees = animal["entrees"]
        regime_attendu = animal["regime"]
        habitat_attendu = animal["habitat"]

        # Calcule les prédictions du réseau.
        probabilites, score_habitat = propagation(entrees)

        # Calcule les erreurs des trois neurones alimentaires.
        for n in range(3):
            erreur = probabilites[n] - (1 if regime_attendu == n else 0)
            gradients_biais[n] += erreur
            for i in range(nombre_entrees):
                gradients_poids[n][i] += erreur * entrees[i]

        # Calcule l'erreur du neurone chargé de l'habitat.
        erreur_habitat = score_habitat - habitat_attendu
        gradients_biais[3] += erreur_habitat
        for i in range(nombre_entrees):
            gradients_poids[3][i] += erreur_habitat * entrees[i]

    # Ajuste les poids et les biais avec les gradients moyens.
    for n in range(nombre_neurones):
        biais[n] -= taux_apprentissage * gradients_biais[n] / nombre_animaux
        for i in range(nombre_entrees):
            poids[n][i] -= taux_apprentissage * gradients_poids[n][i] / nombre_animaux

    # Affiche la progression toutes les 1 000 époques.
    if (epoque + 1) % 1000 == 0:
        print("Epoque :", epoque + 1)

# PHASE 3 - RESTITUTION DES RESULTATS
# Étape 6 : sauvegarde du modèle modele_reseau.json

# Regroupe les paramètres appris par le réseau.
modele = {"poids": poids, "biais": biais, "echelles": echelles}

# Ouvre le fichier en écriture (w).
# Le crée s'il n'existe pas et remplace son ancien contenu.
with open("modele_reseau.json", "w", encoding="utf-8") as fichier:
    json.dump(modele, fichier, indent=4, ensure_ascii=False)

print("\nEntrainement terminé !")
print("Modèle enregistré dans le fichier modele_reseau.json")