# PHASE 1 - PREPARATION DU PROGRAMME 
# Importation, données, paramètres et fonctions

# Étape 1 : importation des bibliothèques
import math

# Étape 2 : initialisation des données
# Liste des animaux, de leurs caractéristiques et de leur habitat.
animaux = [
    ("Lion", [1.1, 190, 80, 1, 1], 1),
    ("Guépard", [0.8, 50, 100, 1, 0], 1),
    ("Léopard", [0.7, 60, 58, 1, 1], 0),
    ("Lycaon", [0.7, 25, 60, 1, 1], 1),
    ("Hyène", [0.8, 65, 60, 1, 1], 1),
    ("Gorille", [1.6, 150, 40, 0, 2], 0),
    ("Okapi", [1.5, 250, 55, 2, 1], 0),
    ("Girafe", [5.0, 1000, 55, 2, 0], 1),
    ("Zèbre", [1.4, 300, 65, 2, 1], 1),
    ("Buffle", [1.5, 650, 55, 2, 2], 1),
    ("Chimpanzé", [1.2, 45, 40, 0, 2], 0),
    ("Mandrill", [0.7, 25, 35, 0, 1], 0),
    ("Babouin", [0.7, 25, 45, 0, 1], 1),
    ("Phacochère", [0.7, 80, 48, 2, 1], 1),
    ("Potamochère", [0.7, 75, 40, 2, 1], 0) ]

# Étape 3 : initialisation des paramètres
# Les poids et le biais seront ajustés pendant l'entraînement.

poids_neurone = [0.0] * 5
biais = 0.0
taux_apprentissage = 0.5
nombre_epoques = 3000

# Étape 4 : définition des fonctions

def normaliser(caracteristiques):
    taille, poids, vitesse, appui, teinte = caracteristiques
    return [taille / 5, poids / 1000, vitesse / 100, appui / 2, teinte / 2]

def sigmoid(z):
    return 1 / (1 + math.exp(-z))

def prediction(caracteristiques):

    # Calcule le résultat à partir des entrées, des poids et du biais.
    entrees = normaliser(caracteristiques)

    # entrees est une variable locale à cette fonction.
    somme = biais
    for i in range(5):
        somme += entrees[i] * poids_neurone[i]
    return sigmoid(somme)

# PHASE 2 - ENTRAINEMENT DU NEURONE
# Calcul des erreurs et ajustement des poids et du biais.

# Étape 5 : apprentissage du neurone

# Répète l'entraînement sur les animaux pendant 3 000 époques.
for epoque in range(nombre_epoques): 

    # Remet les gradients à zéro au début de chaque époque.
    gradients = [0.0] * 5
    gradient_biais = 0.0

    # Parcourt successivement les 15 animaux.
    for nom, caracteristiques, habitat in animaux:

        # Normalise les caractéristiques de l'animal.
        entrees = normaliser(caracteristiques)

        # Calcule la prédiction du neurone.
        resultat = prediction(caracteristiques)

        # Compare le résultat avec l'habitat attendu.
        erreur = resultat - habitat

        # Accumule les gradients pour ajuster les paramètres.
        for i in range(5):
            gradients[i] += erreur * entrees[i]
        gradient_biais += erreur

    nombre_animaux = len(animaux)

    # Ajuste les poids et le biais avec les gradients moyens.
    for i in range(5):
        poids_neurone[i] -= taux_apprentissage * gradients[i] / nombre_animaux
    biais -= taux_apprentissage * gradient_biais / nombre_animaux

# Fin de la boucle d'entraînement.

# PHASE 3 - RESTITUTION DES RESULTATS
# Affichage des poids et du biais après l'entraînement.

# Étape 6 : présentation des résultats

print("ENTRAINEMENT TERMINE")
print("Poids du neurone :")
for i, poids in enumerate(poids_neurone):
    print(f"Poids {i + 1} : {poids:.4f}")
print(f"Biais : {biais:.4f}")

# TEST SUR UN NOUVEL ANIMAL
# Le neurone entraîné prédit l'habitat du rhinocéros blanc.

nom_animal = "Rhinocéros blanc"
nouvel_animal = [1.8, 2000, 40, 2, 1]  

# Calcule le score de prédiction, compris entre 0 et 1.
resultat = prediction(nouvel_animal)

print("\nPREDICTION SUR UN NOUVEL ANIMAL")
print(f"Score de prédiction : {resultat:.4f}")

# Le seuil de 0,5 permet de choisir l'habitat :
# - 0,5 ou plus : savane
# - moins de 0,5 : forêt

if resultat >= 0.5:
    print("Habitat prédit : SAVANE")
else:
    print("Habitat prédit : FORÊT")
