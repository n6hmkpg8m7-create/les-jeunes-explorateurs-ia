import math

# Donnees des animaux : caracteristiques, puis habitat (0 = foret, 1 = savane)
animaux = [
    ("Lion", [1.1, 190, 80, 1, 1], 1),
    ("Guepard", [0.8, 50, 100, 1, 0], 1),
    ("Leopard", [0.7, 60, 58, 1, 1], 0),
    ("Lycaon", [0.7, 25, 60, 1, 1], 1),
    ("Hyenes", [0.8, 65, 60, 1, 1], 1),
    ("Gorille", [1.6, 150, 40, 0, 2], 0),
    ("Okapi", [1.5, 250, 55, 2, 1], 0),
    ("Girafe", [5.0, 1000, 55, 2, 0], 1),
    ("Zebre", [1.4, 300, 65, 2, 1], 1),
    ("Buffle", [1.5, 650, 55, 2, 2], 1),
    ("Chimpanze", [1.2, 45, 40, 0, 2], 0),
    ("Mandrill", [0.7, 25, 35, 0, 1], 0),
    ("Babouin", [0.7, 25, 45, 0, 1], 1),
    ("Phacochere", [0.7, 80, 48, 2, 1], 1),
    ("Potamochere", [0.7, 75, 40, 2, 1], 0)
]

def normaliser(caracteristiques):
    taille, poids, vitesse, appui, teinte = caracteristiques
    return [taille / 5, poids / 1000, vitesse / 100, appui / 2, teinte / 2]

def sigmoid(z):
    return 1 / (1 + math.exp(-z))

poids_neurone = [0.0] * 5
biais = 0.0

def prediction(caracteristiques):
    entrees = normaliser(caracteristiques)
    somme = biais
    for i in range(5):
        somme += entrees[i] * poids_neurone[i]
    return sigmoid(somme)

taux_apprentissage = 0.5
nombre_epoques = 3000

for epoque in range(nombre_epoques):
    gradients = [0.0] * 5
    gradient_biais = 0.0
    for nom, caracteristiques, habitat in animaux:
        entrees = normaliser(caracteristiques)
        resultat = prediction(caracteristiques)
        erreur = resultat - habitat
        for i in range(5):
            gradients[i] += erreur * entrees[i]
        gradient_biais += erreur

    nombre_animaux = len(animaux)
    for i in range(5):
        poids_neurone[i] -= taux_apprentissage * gradients[i] / nombre_animaux
    biais -= taux_apprentissage * gradient_biais / nombre_animaux

print("ENTRAINEMENT TERMINE")
print("--------------------")
print("Poids du neurone :")
for i, poids in enumerate(poids_neurone):
    print(f"Poids {i + 1} : {poids:.4f}")
print(f"Biais : {biais:.4f}")

# Test sur un nouvel animal : rhinoceros blanc
nouvel_animal = [1.8, 2000, 40, 2, 1]
resultat = prediction(nouvel_animal)
print("\nPREDICTION")
print("---Rhinoceros blanc -------")
print(f"Score savane : {resultat:.4f}")
if resultat >= 0.5:
    print("Habitat predit : SAVANE")
else:
    print("Habitat predit : FORET")
